/**
 * 
 */
package com.metallica.common.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.metallica.common.enums.Side;
import com.metallica.common.enums.TradeStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author dkum74
 *
 */
@Document(collection = "trade_data")
@AllArgsConstructor @NoArgsConstructor @Getter @Setter @ToString
public class Trade implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8192077507675160798L;

	@Id
	private String id;
	
	private Long tradeId;
	
	private Side side;
	
	private int quantity;
	
	private BigDecimal price;
	
	@DateTimeFormat(iso=ISO.DATE_TIME)
	private Date tradeDate;
	
	private TradeStatus status;

	private String commodity;
	
	private String counterParty;
	
	private String location;
	
	private String activeFlag;
	
	

}
