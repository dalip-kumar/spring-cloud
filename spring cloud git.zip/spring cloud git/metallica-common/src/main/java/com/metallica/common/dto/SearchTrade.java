/**
 * 
 */
package com.metallica.common.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author dkum74
 *
 */
@AllArgsConstructor @NoArgsConstructor @Getter @Setter @ToString
public class SearchTrade {
	private String tradeId;
	private String fromDate;
	private String toDate;
	private String commodity;
	private String side;
	private String counterParty;
	private String location;
	
	
	
}
