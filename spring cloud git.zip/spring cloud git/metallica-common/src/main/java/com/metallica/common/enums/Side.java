/**
 * 
 */
package com.metallica.common.enums;

/**
 * @author dkum74
 *
 */
public enum Side {

	BUY,
	
	SELL
}
