/*package com.metallica.discovery;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.netflix.eureka.EurekaDiscoveryClient;
import org.springframework.test.annotation.DirtiesContext;

@RunWith(SpringRunner.class)
@SpringBootTest
@DirtiesContext
public class ApplicationTest {

	@Autowired
	DiscoveryClient discoveryClient;

	@Test
	public void contextLoads() {
	}

	@Test
	public void discoveryClientIsEureka() {
		assertTrue("discoveryClient is wrong type: " + discoveryClient, 
				discoveryClient instanceof CompositeDiscoveryClient);
		assertTrue("composite discovery client should have a Eureka client with higher precendence"
				, ((CompositeDiscoveryClient)discoveryClient).getDiscoveryClients().get(0) instanceof EurekaDiscoveryClient);
	}

}
*/