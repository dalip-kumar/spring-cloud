package com.metallica.marketdata.service;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.metallica.common.dto.MarketData;
import com.metallica.common.enums.Direction;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MarketDataSchedulerTest {

	@Mock
	MarketDataService dataService;
	
	@Mock
	MarketDataScheduler dataScheduler;
	
    
    @Mock
    private SimpMessagingTemplate template;
    
	@Before
	public void setup(){

		List<MarketData> marketData = new ArrayList<>();
    	marketData.add(new MarketData("IBM", "IBM", 1222.23, Direction.UP));
    	marketData.add(new MarketData("JP Morgan", "JPM", 122.267, Direction.DOWN));
    	when(dataService.getMarketData()).thenReturn(marketData);
    	
    	doNothing().when(template).convertAndSend(any(String.class), anyListOf(MarketData.class));
		
	}
	
	@Test
	public void testPublishUpdates(){
		doNothing().when(dataScheduler).publishUpdates();
		dataScheduler.publishUpdates();
	    verify(dataScheduler, times(1)).publishUpdates();
	}
}
