package com.metallica.marketdata.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig extends AbstractWebSocketMessageBrokerConfigurer {

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        //config.enableSimpleBroker("/topic");
    	/*config.enableStompBrokerRelay("/queue/", "/topic/")
		.setUserDestinationBroadcast("/topic/unresolved.user.dest")
		.setUserRegistryBroadcast("/topic/registry.broadcast")
		.setRelayHost("localhost")
		.setRelayPort(61613);
    	//15672*/
    	config.enableStompBrokerRelay("/queue/", "/topic/", "/exchange/")
    	.setRelayHost("localhost")
        .setRelayPort(61613)
        .setSystemLogin("guest")
        .setSystemPasscode("guest");
    	
        config.setApplicationDestinationPrefixes("/app");
        
        

    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/livescore-websocket").setAllowedOrigins("*"). withSockJS();
    }

}