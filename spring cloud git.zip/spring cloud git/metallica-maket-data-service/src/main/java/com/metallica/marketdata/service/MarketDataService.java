package com.metallica.marketdata.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.metallica.common.dto.MarketData;
import com.metallica.common.enums.Direction;


@Component
public class MarketDataService {
    
	private int MAXPRICE = 1000;
    
	private List<MarketData> marketData = new ArrayList<>();
    
    private Random rand = new Random();
    
    public List<MarketData> getMarketData() {
    	if(marketData.isEmpty()){
    		marketData = getInitalData();
    	}
    	
    	marketData.parallelStream().forEach(m -> {
    		double currentPrice = m.getPrice();
    		
			int randPrice = rand.nextInt((MAXPRICE - 100) + 3);
    		if(currentPrice < MAXPRICE){
    			m.setPrice(currentPrice + randPrice);
    			m.setDirection(Direction.UP);
    		}else{
    			m.setPrice(currentPrice - randPrice);
    			m.setDirection(Direction.DOWN);
    		}
    	});
       return marketData;
    }

    private List<MarketData> getInitalData() {
    	List<MarketData> marketData = new ArrayList<>();
    	marketData.add(new MarketData("IBM", "IBM", 1222.23, Direction.UP));
    	marketData.add(new MarketData("JP Morgan", "JPM", 1222.23, Direction.DOWN));
    	marketData.add(new MarketData("Oracle Corp", "ORA", 1222.23, Direction.UP));
    	marketData.add(new MarketData("IGL", "IGL", 1222.23, Direction.DOWN));
    	marketData.add(new MarketData("TCS Info", "TCS", 1222.23, Direction.UP));
    	marketData.add(new MarketData("Infosys", "INF", 1222.23, Direction.DOWN));
    	marketData.add(new MarketData("Yes Bank", "YES", 1222.23, Direction.UP));
    	marketData.add(new MarketData("SUN P", "SUN", 1222.23, Direction.UP));
    	marketData.add(new MarketData("American Express", "AMX", 1222.23, Direction.UP));
    	marketData.add(new MarketData("Bank of America", "BOA", 1222.23, Direction.UP));
    	marketData.add(new MarketData("Videocon", "D2H", 1222.23, Direction.UP));
    	marketData.add(new MarketData("Reliance Ind.", "RIL", 1222.23, Direction.UP));
    	marketData.add(new MarketData("Tata Ind.", "TAT", 1222.23, Direction.UP));
        return marketData;
    }

}