package com.metallica.server.trade.service;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
@ActiveProfiles(profiles = "junit")
@RunWith(SpringRunner.class)
@SpringBootTest
public class NextSequenceServiceTest {

	@Mock
	private NextSequenceService nextSeqService;
	
	@Before
	public void setUp(){
		when(nextSeqService.getNextSequence("tradeId")).thenReturn(599L);
	}
	@Test
	public void testGetNextSequence(){
		Assert.assertEquals( nextSeqService.getNextSequence("tradeId"), 599L);
	}
}
