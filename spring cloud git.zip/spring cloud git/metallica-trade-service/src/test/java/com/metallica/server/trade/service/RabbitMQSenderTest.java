package com.metallica.server.trade.service;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.metallica.common.dto.Trade;
import com.metallica.common.enums.Side;
import com.metallica.common.enums.TradeStatus;

@ActiveProfiles(profiles = "junit")
@RunWith(SpringRunner.class)
@SpringBootTest
public class RabbitMQSenderTest {

	
	@Mock
	private RabbitMQSender<Trade> rabbitMQSender;
	
	@Before
	public void setUp(){
		Trade trade = new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y");
		doNothing().when(rabbitMQSender).send(trade);
		
	}
	
	
	@Test
	public void testSend(){
		Trade trade = new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y");
		rabbitMQSender.send(trade);
	    verify(rabbitMQSender, times(1)).send(trade);
	}
	

}
