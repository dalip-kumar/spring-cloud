package com.metallica.server.trade.service;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
@ActiveProfiles(profiles = "junit")
@RunWith(SpringRunner.class)
@SpringBootTest
public class SequenceDaoImplTest {

	
	@Mock
	private SequenceDao sequenceDao;
	
	@Before
	public void setUp(){
		
		long nextSequanceId = 333;
		when(sequenceDao.getNextSequenceId("tradeId")).thenReturn(nextSequanceId);
		
	}
	@Test
	public void testGetNextSequenceId(){

		Assert.assertEquals(sequenceDao.getNextSequenceId("tradeId") , 333);
	}
	

}
