/**
 * 
 */
package com.metallica.server.trade.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.metallica.common.dto.SearchTrade;
import com.metallica.common.dto.Trade;
import com.metallica.common.dto.TradeForm;
import com.metallica.server.trade.service.RabbitMQSender;
import com.metallica.server.trade.service.TradeService;

/**
 * @author dkum74
 *
 */

@RestController
@RequestMapping(path="/trades")
public class TradeController {
	


	@Autowired
	private TradeService tradeService;
	
	@Autowired
	RabbitMQSender<Collection<Trade>> rabbitMQSender;
	
	@RequestMapping(method = RequestMethod.GET)
	public Collection<Trade> getTrades(@ModelAttribute SearchTrade searchCrit){
			return tradeService.getTrades(searchCrit);
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public void createTrade(@RequestBody TradeForm tradeForm){
		tradeService.createTrade(tradeForm);
		rabbitMQSender.send(tradeService.getTrades());
	}
	
	@RequestMapping(method = RequestMethod.PUT,  value = "/{tradeId}")
	public void updateTrade(@RequestBody TradeForm tradeForm, @PathVariable("tradeId") long tradeId){
		tradeService.updateTrade(tradeForm, tradeId);
		rabbitMQSender.send(tradeService.getTrades());
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/{tradeId}")
	public void deleteTrade(@PathVariable("tradeId") long tradeId){
		tradeService.deleteTrade(tradeId);
		rabbitMQSender.send(tradeService.getTrades());
	}
	
}
