package com.metallica.referencedata.service;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.metallica.common.dto.Commodity;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CommodityRepoTest {

	@Mock
	CommodityRepo commodityRepo;
    
	@Before
	public void setup(){

		List<Commodity> data = new ArrayList<>();
		data.add(new Commodity("IBM","IBM","IBM Corporation"));
		when(commodityRepo.findByname("IBM")).thenReturn(data);
	}
	
	@Test
	public void testPublishUpdates(){
		List<Commodity> commodities = commodityRepo.findByname("IBM");
		Assert.assertEquals("IBM", commodities.get(0).getId());
		Assert.assertEquals("IBM", commodities.get(0).getName());
		Assert.assertEquals("IBM Corporation", commodities.get(0).getDescription());
	}
}
