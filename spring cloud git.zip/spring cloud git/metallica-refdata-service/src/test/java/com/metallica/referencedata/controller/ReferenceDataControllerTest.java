package com.metallica.referencedata.controller;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.metallica.common.dto.Commodity;
import com.metallica.common.dto.CounterParty;
import com.metallica.common.dto.Location;
import com.metallica.referencedata.service.CommodityRepo;
import com.metallica.referencedata.service.CounterPartyRepo;
import com.metallica.referencedata.service.LocationRepo;
@ActiveProfiles(profiles = "junit")
@RunWith(SpringRunner.class)
@WebMvcTest(ReferenceDataController.class)
public class ReferenceDataControllerTest {

	@Autowired
    private MockMvc mvc;

	@MockBean
    private CounterPartyRepo counterPartyRepo;

	@MockBean
    private LocationRepo locationRepo;

	@MockBean
    private CommodityRepo commodityRepo;

	@Before
	public void setUp(){
		
		List<CounterParty> counterParty = new ArrayList<>();
		counterParty.add(new CounterParty("1","AAPL","Apple", "Apple Corporation"));
		when(counterPartyRepo.findBySym("AAPL")).thenReturn(counterParty);
		
		List<CounterParty> counterParties = new ArrayList<>();
		counterParties.add(new CounterParty("1","AAPL","Apple", "Apple Corporation"));
		counterParties.add(new CounterParty("2","CITI","Citi", "Citi Bank"));
		when(counterPartyRepo.findAll()).thenReturn(counterParties);
		
		List<Location> location = new ArrayList<>();
		location.add(new Location("1","US","USA"));
		when(locationRepo.findByCode("US")).thenReturn(location);
		
		List<Location> locations = new ArrayList<>();
		locations.add(new Location("1","US","USA"));
		locations.add(new Location("2","IND","INDIA"));
		when(locationRepo.findAll()).thenReturn(locations);
		
		List<Commodity> commodity = new ArrayList<>();
		commodity.add(new Commodity("1","IBM","IBM Corporation"));
		when(commodityRepo.findByname("IBM")).thenReturn(commodity);
		
		List<Commodity> commodities = new ArrayList<>();
		commodities.add(new Commodity("1","IBM","IBM Corporation"));
		commodities.add(new Commodity("2","ORA","Oracle Corp"));
		when(commodityRepo.findAll()).thenReturn(commodities);
		
	}
	
	@Test
	public void testGetCountryParty() throws Exception{
		String expectedResult = "{\"id\":\"1\",\"sym\":\"AAPL\",\"name\":\"Apple\",\"description\":\"Apple Corporation\"}";
		mvc.perform(get("/countryparty/AAPL").accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk()).andExpect(content().json(expectedResult));
	}
	
	@Test
	public void testGetCountryParties() throws Exception{
		String expectedResult = "[{\"id\":\"1\",\"sym\":\"AAPL\",\"name\":\"Apple\",\"description\":\"Apple Corporation\"},{\"id\":\"2\",\"sym\":\"CITI\",\"name\":\"Citi\",\"description\":\"Citi Bank\"}]";
		mvc.perform(get("/countryparty").accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk()).andExpect(content().json(expectedResult));
	}
	
	@Test
	public void testGetLocation() throws Exception {
		String expectedResult = "{\"id\":\"1\",\"code\":\"US\",\"name\":\"USA\"}";
		mvc.perform(get("/location/US").accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk()).andExpect(content().json(expectedResult));
	}
	
	@Test
	public void testGetLocations() throws Exception {
		String expectedResult = "[{\"id\":\"1\",\"code\":\"US\",\"name\":\"USA\"},{\"id\":\"2\",\"code\":\"IND\",\"name\":\"INDIA\"}]";
		mvc.perform(get("/location").accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk()).andExpect(content().json(expectedResult));
	}
	
	@Test
	public void testGetCommodity() throws Exception {
		String expectedResult = "{\"id\":\"1\",\"name\":\"IBM\",\"description\":\"IBM Corporation\"}";
		mvc.perform(get("/commodity/IBM").accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk()).andExpect(content().json(expectedResult));
	}
	
	@Test
	public void testGetCommoditys() throws Exception {
		String expectedResult = "[{\"id\":\"1\",\"name\":\"IBM\",\"description\":\"IBM Corporation\"},{\"id\":\"2\",\"name\":\"ORA\",\"description\":\"Oracle Corp\"}]";
		mvc.perform(get("/commodity").accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk()).andExpect(content().json(expectedResult));
	}
}
