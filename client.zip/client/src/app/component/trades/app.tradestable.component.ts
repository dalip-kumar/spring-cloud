import { Component, TemplateRef, OnInit, OnDestroy  } from '@angular/core';
import {TradeService} from 'app/service/app.trades.service';
import { BsModalService,ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import {Subscription} from "rxjs/Subscription";
import {MessageService} from "app/service/message.service";
@Component({
  selector: 'app-metallica-trades',
  templateUrl: './app.tradestable.component.html',
  styleUrls: ['./app.tradestable.component.css'],
  providers: []
})
export class TradesTableComponent  implements OnInit, OnDestroy{
  trades;
  modalRef: BsModalRef;
  selectedTrade;

  messages: Array<string> = [];

  messageSub: Subscription;
  
  tradeFilterSub: Subscription;
  currentFilters;
  
  allTrades;
  
  constructor(private tradeService:TradeService, private modalService: BsModalService,
    private messageService: MessageService,){
    tradeService.getTrades(null).subscribe(data => {
      this.allTrades = data
      this.onFilterTrade();
      }
    );
    
  }

  ngOnInit(){
    this.messageSub = this.messageService.messageReceived$.subscribe( data => {
      this.allTrades = data
      this.onFilterTrade();
    });

    this.tradeFilterSub = this.tradeService.getFilterTrades().subscribe(data => {
       this.currentFilters = data;
       this.onFilterTrade();
     });
  }
  onDeleteTrade(template: TemplateRef<any>, tradeDetail){
    this.selectedTrade = tradeDetail;
    this.modalRef = this.modalService.show(template, {class: 'modal-sm'});

  }
  onViewTrade(tradeDetail){
    this.tradeService.setTradeDetail(tradeDetail);
  }

  deleteTrade(){
    
    this.tradeService.deleteTrade(this.selectedTrade.tradeId).subscribe(data => {
      
      this.modalRef.hide();
    });
  }
 
  onFilterTrade(){
    if(this.currentFilters != undefined && this.currentFilters != null){
      var filterKeys = Object.keys(this.currentFilters).filter(filter => {
        var value = this.currentFilters[filter];
        if(value != undefined &&  value != null && value != ""){
          return true;
        }
        return false;
      });

      let filteredTrades = this.allTrades.filter(trade => {
        var keepRecord = true;
      
        let result = filterKeys.map((key, index) => {
          if(key == "fromDate" || key == "toDate"){
            var fromDateValue = this.currentFilters["fromDate"];
            var fromFilterDate = new Date(fromDateValue['year'],fromDateValue['month']-1,fromDateValue['day']);

            var toDateValue = this.currentFilters["toDate"];
            var toFilterDate = new Date(toDateValue['year'],toDateValue['month']-1,toDateValue['day']);

            var tradeDateTime = new Date(trade["tradeDate"]);
            var tradeDate = new Date(tradeDateTime.getFullYear(), tradeDateTime.getMonth(), tradeDateTime.getDate())

            if(tradeDate >= fromFilterDate && tradeDate <= toFilterDate ){
              keepRecord = true;
            }else{
              keepRecord = false;
            }
          }
          else if(this.currentFilters[key] != trade[key]){
            keepRecord = false;
          }
        });
      
        return keepRecord;
      }

      );

      this.trades = filteredTrades;

      
    }else {
      this.trades = this.allTrades;
    }
  }
  ngOnDestroy() {
    if ( this.messageSub ) {
     this.messageSub.unsubscribe();
   }
   
   if(this.tradeFilterSub){
    this.tradeFilterSub.unsubscribe();
  }
  
 }
}
