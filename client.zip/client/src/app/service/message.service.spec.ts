import {
    fakeAsync,
    inject,
    TestBed,
    tick
  } from '@angular/core/testing';
import { MessageService } from 'app/service/message.service';
import { MessageServiceStub } from 'app/service/message.service.stub';
  
const mockMarketDataResponse = [
  {"name":"IBM","sym":"IBM","price":788.23,"direction":"UP"},
  {"name":"JP Morgan","sym":"JPM","price":1085.23,"direction":"DOWN"}
]; 

const mockTradeDataResponse = [
  {"id":"5a7053d210e4a220d097e194","tradeId":33,"side":"BUY","quantity":222,"price":23,"tradeDate":1514937600000,"status":"OPEN","commodity":"Sit","counterParty":"IBM Inc.","location":"India","activeFlag":"Y"},
  {"id":"5a7ec4dd61ed3d1c20050b04","tradeId":34,"side":"BUY","quantity":23,"price":898,"tradeDate":1517443200000,"status":"OPEN","commodity":"Sit","counterParty":"Apple Inc.","location":"India","activeFlag":"Y"}
];

describe('MessageService', () => {
    let service: MessageServiceStub;

    beforeEach(() => {
        TestBed.configureTestingModule({
        
          providers: [
            
            {
              provide: MessageService,
              useClass: MessageServiceStub

            }
            
          ]
        });
      });


    it('should get market data message ', fakeAsync(
        inject([MessageService], (messageService: MessageService) => {
          let testData = {};
          testData['body']=JSON.stringify(mockMarketDataResponse);
        
          messageService.marketData$.subscribe(value => {
                let firstRecord = value[0];
                expect(value.length).toBe(2);
                expect(firstRecord['name']).toBe("IBM");
          });
              messageService.onMarketData(testData);
        })
      ));


      it('should get Trade data message ', fakeAsync(
        inject([MessageService], (messageService: MessageService) => {
          let testData = {};
          testData['body']=JSON.stringify(mockTradeDataResponse);
        
          messageService.messageReceived$.subscribe(value => {
                let firstRecord = value[0];
                expect(value.length).toBe(2);
                expect(firstRecord['tradeId']).toBe(33);
          });
              messageService.onTradeData(testData);
        })
      ));
    
   
   
    });