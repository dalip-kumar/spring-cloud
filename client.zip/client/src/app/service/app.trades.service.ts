import {Injectable} from '@angular/core';
import {Http, Response, RequestOptions, Headers, URLSearchParams, RequestOptionsArgs} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import { Console } from '@angular/core/src/console';
import {Subject} from 'rxjs/Subject';
import {Observable} from 'rxjs/Rx';

@Injectable()
export class TradeService {
  headers: Headers;
  options: RequestOptions;
  
  referenceDataUrl: string = '/reference';
  tradeDataUrl: string = '/tradedata';
  trades;
  private newtradeDetail = new Subject<any>();
  
  private tradeFilters = new Subject<any>();

  private errorLogs = new Subject<any>();

  constructor(private http:Http){
   // this.headers = new Headers({ 'Content-Type': 'application/json', 
    //'Accept': 'q=0.8;application/json;q=0.9' });
  //  this.options = new RequestOptions({headers: this.headers });
  }

  
  getTrades(tradeDetail){
    let params: URLSearchParams = new URLSearchParams();
    
    for (var key in tradeDetail) {
        if (tradeDetail.hasOwnProperty(key)) {
            let val = tradeDetail[key];
            params.set(key, val);
        }
    }
    
    this.options = new RequestOptions({search: params });

 
    return this.http.get(this.tradeDataUrl+'/trades', this.options)
    .map((res:Response) => res.json());
    
  }

  createTrade(tradeDetail){

    let headers = new Headers();
    headers.append('Content-Type','application/json');

    let reqOptions:RequestOptionsArgs = {};
    reqOptions.body = JSON.stringify(tradeDetail);
    reqOptions.headers = headers;
    reqOptions.method ='POST';

   return this.http.request(this.tradeDataUrl+'/trades',reqOptions);
       
  }

  setTradeDetail(data){
    this.newtradeDetail.next(data);
  }

  getTradeDetail(){
    return this.newtradeDetail.asObservable();
  }


  setFilterTrades(data){
    this.tradeFilters.next(data);
  }

  getFilterTrades(){
    return this.tradeFilters.asObservable();
  }

  updateTrade(tradeDetail, tradeId){
    let headers = new Headers();
    headers.append('Content-Type','application/json');

    let reqOptions:RequestOptionsArgs = {};
    reqOptions.body = JSON.stringify(tradeDetail);
    reqOptions.headers = headers;
    reqOptions.method ='PUT';
    let myParams = new URLSearchParams();
    //alert(this.getCookie('XSRF-TOKEN'));
    //myParams.append('_csrf', this.getCookie('XSRF-TOKEN'));	
    reqOptions.params = myParams;

   return this.http.request(this.tradeDataUrl+'/trades/'+tradeId,reqOptions);

  }
  deleteTrade(tradeId){
    let headers = new Headers();
    headers.append('Content-Type','application/json');
   // reqOptions.body = JSON.stringify({"tradeId":tradeId});

    return this.http.delete(this.tradeDataUrl+'/trades/'+tradeId, new RequestOptions({
      headers: headers
      
   }));
  }

  getCommodity(commodity){
 
    return this.http.get(this.referenceDataUrl+'/commodity/'+commodity).map((res:Response) => res.json());
    
  }
  getCommodities(){
 
    return this.http.get(this.referenceDataUrl+'/commodity').map((res:Response) => res.json());
    
  }
  
  getCounterParties(){
    return this.http.get(this.referenceDataUrl+'/counterparty').map((res:Response) => res.json());
  }
  getLocations(){
    return this.http.get(this.referenceDataUrl+'/location').map((res:Response) => res.json());
  }
  getSides(){
    return ['BUY','SELL'];
  }

  handleError(errorMessage){
    this.errorLogs.next(errorMessage);
  }
  getErrorLog(){
    return this.errorLogs.asObservable();
  }

  


  getCookie(name: string) {
    let ca: Array<string> = document.cookie.split(';');
    let cookieName = name + "=";
    let c: string;

    for (let i: number = 0; i < ca.length; i += 1) {
        if (ca[i].indexOf(name, 0) > -1) {
            c = ca[i].substring(cookieName.length +1, ca[i].length);
            console.log("valore cookie: " + c);
            return c;
        }
    }
    return "";
  }





}
