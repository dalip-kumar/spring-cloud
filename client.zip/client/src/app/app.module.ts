import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
//import { FormsModule } from '@angular/forms';
import { HttpModule,XSRFStrategy,CookieXSRFStrategy } from '@angular/http';
import { AppComponent } from './component/app.component';
import { SearchComponent } from './component/trade-search/app.search.component';
import {TradesTableComponent} from './component/trades/app.tradestable.component';
import {TradeDetailComponent} from './component/trade-detail/app.tradedetail.component';
import {TickerComponent} from './component/ticker/app.ticker.component';

import { ReactiveFormsModule } from '@angular/forms';
import {MessageService} from "./service/message.service";
import {MyDatePickerModule} from '../../node_modules/angular4-datepicker/src/my-date-picker/my-date-picker.module';
import { ModalModule } from 'ngx-bootstrap/modal';
import {TradeService} from './service/app.trades.service';
import {GlobalErrorHandler} from './service/app.error-handler';
import { ErrorHandlerComponent } from './component/error/app.error.component';


@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    TradesTableComponent,
    TradeDetailComponent,
    TickerComponent,
    ErrorHandlerComponent
  ],
  imports: [
    BrowserModule,
  //  FormsModule,
    HttpModule,
    ReactiveFormsModule,
    MyDatePickerModule,
    ModalModule.forRoot()
    
  ],
  providers: [
    MessageService,
    TradeService,
    {
      provide: ErrorHandler, 
      useClass: GlobalErrorHandler
    }/*,
    {provide: XSRFStrategy, useValue: new CookieXSRFStrategy('XSRF-TOKEN', 'X-XSRF-TOKEN')}*/
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
