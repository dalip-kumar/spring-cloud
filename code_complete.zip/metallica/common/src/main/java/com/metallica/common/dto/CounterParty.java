/**
 * 
 */
package com.metallica.common.dto;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author dkum74
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Document(collection = "counterparty_data")
@AllArgsConstructor @NoArgsConstructor @Getter @Setter @ToString
public class CounterParty {

	private String id;
	
	private String sym;
	
	private String name;
	
	private String description;

	
	
	
}
