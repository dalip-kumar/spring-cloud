package com.metallica.common.enums;

public enum TradeStatus {

	OPEN,
	NOMINATED
}
