package com.metallica.common.dto;

import java.io.Serializable;

import com.metallica.common.enums.Direction;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor @NoArgsConstructor @Getter @Setter @ToString
public class MarketData implements Serializable{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;
    
	private String sym;
	
    private double price;

    private Direction direction;
    
}