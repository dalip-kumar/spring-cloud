package com.metallica.referencedata.service;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.metallica.common.dto.CounterParty;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CounterPartyRepoTest {

	@Mock
	CounterPartyRepo counterPartyRepo;
    
	@Before
	public void setup(){

		List<CounterParty> data = new ArrayList<>();
		data.add(new CounterParty("1","AAPL","Apple", "Apple Corporation"));
		when(counterPartyRepo.findBySym("AAPL")).thenReturn(data);
	}
	
	@Test
	public void testPublishUpdates(){
		List<CounterParty> counterParties = counterPartyRepo.findBySym("AAPL");
		Assert.assertEquals("1", counterParties.get(0).getId());
		Assert.assertEquals("AAPL", counterParties.get(0).getSym());
		Assert.assertEquals("Apple", counterParties.get(0).getName());
		Assert.assertEquals("Apple Corporation", counterParties.get(0).getDescription());
	}
}
