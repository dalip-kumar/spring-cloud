package com.metallica.referencedata.service;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.metallica.common.dto.Location;

@RunWith(SpringRunner.class)
@SpringBootTest
public class LocationRepoTest {

	@Mock
	LocationRepo locationRepo;
    
	@Before
	public void setup(){

		List<Location> data = new ArrayList<>();
		data.add(new Location("1","US","USA"));
		when(locationRepo.findByCode("US")).thenReturn(data);
	}
	
	@Test
	public void testPublishUpdates(){
		List<Location> counterParties = locationRepo.findByCode("US");
		Assert.assertEquals("1", counterParties.get(0).getId());
		Assert.assertEquals("US", counterParties.get(0).getCode());
		Assert.assertEquals("USA", counterParties.get(0).getName());
	}
}
