/**
 * 
 */
package com.metallica.referencedata.service;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.metallica.common.dto.Commodity;

/**
 * @author dkum74
 *
 */
public interface CommodityRepo extends MongoRepository<Commodity, String> {

	public List<Commodity> findByname(String name);
}
