package com.metallica.referencedata.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.metallica.common.dto.Commodity;
import com.metallica.common.dto.CounterParty;
import com.metallica.common.dto.Location;
import com.metallica.common.exception.RecordNotFoundException;
import com.metallica.referencedata.service.CommodityRepo;
import com.metallica.referencedata.service.CounterPartyRepo;
import com.metallica.referencedata.service.LocationRepo;

@RestController
public class ReferenceDataController {

	
	@Autowired
	private CounterPartyRepo counterRepo;
	
	@Autowired
	private LocationRepo locationRepo;
	
	@Autowired
	private CommodityRepo commodityRepo;
	
	@RequestMapping(method=RequestMethod.GET, value="/counterparty/{sym}")
	public ResponseEntity<CounterParty> getCountryParty(@PathVariable("sym") String sym){
		List<CounterParty> counterParty = counterRepo.findBySym(sym);
		if(counterParty != null && !counterParty.isEmpty()){
			return new ResponseEntity<CounterParty>(counterParty.get(0), HttpStatus.OK);
		}
		throw new RecordNotFoundException("Counter party "+sym+" not found");
		
	}
	@RequestMapping(method=RequestMethod.GET, value="/counterparty")
	public ResponseEntity<List<CounterParty>> getCountryParties(){
		List<CounterParty> counterParty = counterRepo.findAll();
		if(counterParty != null && !counterParty.isEmpty()){
			return new ResponseEntity<List<CounterParty>>(counterParty, HttpStatus.OK);
		}
		throw new RecordNotFoundException("Counter party  not found");
		
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/location/{code}")
	public ResponseEntity<Location> getLocation(@PathVariable("code") String code){
		List<Location> locations = locationRepo.findByCode(code);
		if(locations != null && !locations.isEmpty()){
			return new ResponseEntity<Location>(locations.get(0), HttpStatus.OK);
		}
		throw new RecordNotFoundException("Location "+code+" not found");
		
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/location")
	public ResponseEntity<List<Location>> getLocations(){
		List<Location> locations = locationRepo.findAll();
		if(locations != null && !locations.isEmpty()){
			return new ResponseEntity<List<Location>>(locations, HttpStatus.OK);
		}
		throw new RecordNotFoundException("Location not found");
		
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/commodity/{name}")
	public ResponseEntity<Commodity> getCommodity(@PathVariable("name") String name){
		List<Commodity> commodities = commodityRepo.findByname(name);
		if(commodities != null && !commodities.isEmpty()){
			return new ResponseEntity<Commodity>(commodities.get(0), HttpStatus.OK);
		}
		throw new RecordNotFoundException("Commodity "+name+" not found");
		
	}
	@RequestMapping(method=RequestMethod.GET, value="/commodity")
	public ResponseEntity<List<Commodity>> getCommodity(){
		List<Commodity> commodities = commodityRepo.findAll();
		if(commodities != null && !commodities.isEmpty()){
			return new ResponseEntity<List<Commodity>>(commodities, HttpStatus.OK);
		}
		throw new RecordNotFoundException("Commodity not found");
		
	}
}
