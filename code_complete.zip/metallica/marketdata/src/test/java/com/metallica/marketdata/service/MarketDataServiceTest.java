package com.metallica.marketdata.service;
import org.junit.Before;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.metallica.common.dto.MarketData;
import com.metallica.common.enums.Direction;

import static org.mockito.Mockito.mock;
@RunWith(SpringRunner.class)
@SpringBootTest

public class MarketDataServiceTest {

	private MarketDataService dataService;
	
	@Before
	public void setup(){
		dataService = mock(MarketDataService.class);
	}
	
	@Test
	public void testGetMarketData(){
		List<MarketData> marketData = new ArrayList<>();
    	marketData.add(new MarketData("IBM", "IBM", 1222.23, Direction.UP));
    	marketData.add(new MarketData("JP Morgan", "JPM", 122.267, Direction.DOWN));
    	
		when(dataService.getMarketData()).thenReturn(marketData);

		Assert.assertEquals(dataService.getMarketData().get(0).getSym(), "IBM");
		Assert.assertEquals(dataService.getMarketData().get(0).getName(), "IBM");
		Assert.assertEquals(dataService.getMarketData().get(0).getDirection(), Direction.UP);

		Assert.assertEquals(dataService.getMarketData().get(1).getSym(), "JPM");
		Assert.assertEquals(dataService.getMarketData().get(1).getName(), "JP Morgan");
		Assert.assertEquals(dataService.getMarketData().get(1).getDirection(), Direction.DOWN);
	}
}
