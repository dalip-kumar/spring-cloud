package com.metallica.server.trade.controller;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.metallica.common.dto.Trade;
import com.metallica.common.dto.TradeForm;
import com.metallica.common.enums.Side;
import com.metallica.common.enums.TradeStatus;
import com.metallica.server.trade.service.NextSequenceService;
import com.metallica.server.trade.service.RabbitMQSender;
import com.metallica.server.trade.service.SequenceDao;
import com.metallica.server.trade.service.TradeService;
@ActiveProfiles(profiles = "junit")
@RunWith(SpringRunner.class)
@WebMvcTest(TradeController.class)
public class TradeControllerTest {

	@Autowired
    private MockMvc mvc;

	@MockBean
	private TradeService tradeService;

	@MockBean
	private NextSequenceService nextSeqService;
	
	@MockBean
	private SequenceDao sequenceDao;

	@MockBean
	RabbitMQSender<Collection<Trade>> rabbitMQSender;
	
	@Autowired
	ObjectMapper mapper;
	
	@Before
	public void setUp() {
		List<Trade> expectedTrades = new ArrayList<>();
		expectedTrades.add(new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(2018,1,23), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y"));
		expectedTrades.add(new Trade("2",2L, Side.SELL, 150, new BigDecimal(161.2), new Date(2018,1,22), TradeStatus.OPEN, "AKS", "CITI", "US", "Y"));
		when(tradeService.getTrades(anyObject())).thenReturn(expectedTrades);

		Trade newTrade = new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(2018,1,23), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y");
		when(tradeService.createTrade(anyObject())).thenReturn(newTrade);
		
		
		Trade updateTrade = new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(2018,1,23), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y");
		when(tradeService.updateTrade(anyObject(), anyLong())).thenReturn(updateTrade);
		
		Trade deleteTrade = new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(2018,1,23), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y");
		when(tradeService.deleteTrade(anyLong())).thenReturn(deleteTrade);
		
		doNothing().when(rabbitMQSender).send(expectedTrades);
		
		
	}
	
	@Test
	public void testGetTrades() throws Exception{
		
		List<Trade> resultTrades = new ArrayList<>();
		resultTrades.add(new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(2018,1,23), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y"));
		resultTrades.add(new Trade("2",2L, Side.SELL, 150, new BigDecimal(161.2), new Date(2018,1,22), TradeStatus.OPEN, "AKS", "CITI", "US", "Y"));
		
		mvc.perform(get("/trades").accept(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk()).andExpect(content().json(mapper.writeValueAsString(resultTrades)));
	}
	
	
	
	@Test
	public void testCreateTrade() throws  Exception{
		TradeForm form = new TradeForm();
		form.setSide(Side.BUY.toString());
		form.setCounterParty("CounterParty");
		
		mvc.perform(post("/trades").contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(form)))
			.andExpect(status().isOk());
	}
	
	@Test
	public void testUpdateTrade() throws  Exception{
		TradeForm form = new TradeForm();
		form.setSide(Side.BUY.toString());
		form.setCounterParty("CounterParty");
		
		mvc.perform(put("/trades/1").contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(form)))
			.andExpect(status().isOk());
	}
	
	@Test
	public void testDeleteTrade() throws  Exception{
		
		mvc.perform(delete("/trades/1").contentType(MediaType.APPLICATION_JSON))
			.andExpect(status().isOk());
	}
}
