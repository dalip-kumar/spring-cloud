package com.metallica.server.trade.service;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyLong;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.metallica.common.dto.SearchTrade;
import com.metallica.common.dto.Trade;
import com.metallica.common.dto.TradeForm;
import com.metallica.common.enums.Side;
import com.metallica.common.enums.TradeStatus;
@ActiveProfiles(profiles = "junit")
@RunWith(SpringRunner.class)
@SpringBootTest
public class TradeServiceImplTest {

	
	@Mock
	private TradeService tradeService;
	
	@Before
	public void setUp(){
		List<Trade> trades = new ArrayList<>();
		trades.add(new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y"));
		trades.add(new Trade("2",2L, Side.SELL, 150, new BigDecimal(161.2), new Date(), TradeStatus.OPEN, "AKS", "CITI", "US", "Y"));
		
		when(tradeService.getTrades()).thenReturn(trades);
		
		List<Trade> searchTradeResult = trades.stream().filter(trade -> 
			(trade.getSide().toString().equals(Side.SELL.toString())  && "US".equals(trade.getLocation()))
		).collect(Collectors.toList());
		
		when(tradeService.getTrades(anyObject())).thenReturn(searchTradeResult);
		
		Trade newTrade = new Trade("1",150L, Side.BUY, 50, new BigDecimal(101.2), new Date(), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y");
		when(tradeService.createTrade(anyObject())).thenReturn(newTrade);
		
		Trade removeTrade = new Trade("1",150L, Side.BUY, 50, new BigDecimal(101.2), new Date(), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y");
		when(tradeService.deleteTrade(1L)).thenReturn(removeTrade);
		
		Trade updateTrade = new Trade("1",150L, Side.BUY, 50, new BigDecimal(101.2), new Date(), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y");
		when(tradeService.updateTrade(anyObject(), anyLong())).thenReturn(updateTrade);
	}
	@Test
	public void testGetTrades(){
		List<Trade> expectedTrades = new ArrayList<>();
		expectedTrades.add(new Trade("1",1L, Side.BUY, 50, new BigDecimal(101.2), new Date(), TradeStatus.OPEN, "AAPL", "IBM", "IND", "Y"));
		expectedTrades.add(new Trade("2",2L, Side.SELL, 150, new BigDecimal(161.2), new Date(), TradeStatus.OPEN, "AKS", "CITI", "US", "Y"));

		Assert.assertEquals( tradeService.getTrades().size(), expectedTrades.size());
	}
	
	@Test
	public void testGetTrades2(){
		List<Trade> expectedTrades = new ArrayList<>();
		expectedTrades.add(new Trade("2",2L, Side.SELL, 150, new BigDecimal(161.2), new Date(), TradeStatus.OPEN, "AKS", "CITI", "US", "Y"));
		
		SearchTrade searchCrit = new SearchTrade();
		searchCrit.setSide(Side.SELL.toString());
		
		Assert.assertEquals( tradeService.getTrades(searchCrit).size(), expectedTrades.size());
	}
	
	@Test
	public void testCreateTrade(){
		TradeForm tradeForm = new TradeForm();
		tradeForm.setCommodity("AAPL");
		tradeForm.setSide(Side.BUY.toString());
		tradeForm.setQuantity("25");
		tradeForm.setPrice("101.2");
		tradeForm.setTradeDate("25-01-2018");
		Trade expectedResult = tradeService.createTrade(tradeForm);
		Assert.assertEquals( expectedResult.getTradeId().longValue(), 150L);
		Assert.assertEquals( expectedResult.getSide(), Side.BUY);
		Assert.assertEquals( expectedResult.getPrice(), new BigDecimal(101.2));
	}
	
	@Test
	public void testDeleteTrade(){
		Trade expectedResult = tradeService.deleteTrade(1L);
		Assert.assertEquals( expectedResult.getTradeId().longValue(), 150L);
		Assert.assertEquals( expectedResult.getSide(), Side.BUY);
		Assert.assertEquals( expectedResult.getPrice(), new BigDecimal(101.2));
	}
	
	@Test
	public void testUpdateTrade(){
		TradeForm tradeForm = new TradeForm();
		tradeForm.setCommodity("AAPL");
		tradeForm.setSide(Side.BUY.toString());
		tradeForm.setQuantity("25");
		tradeForm.setPrice("101.2");
		tradeForm.setTradeDate("25-01-2018");
		
		Trade expectedResult = tradeService.updateTrade(tradeForm, 1L);
		Assert.assertEquals( expectedResult.getTradeId().longValue(), 150L);
		Assert.assertEquals( expectedResult.getSide(), Side.BUY);
		Assert.assertEquals( expectedResult.getPrice(), new BigDecimal(101.2));
	}
}
