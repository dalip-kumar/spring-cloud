package com.metallica.server.trade.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQSender<T> {

    @Autowired
    private SimpMessagingTemplate template;
    
	@Value("${metallica.rabbitmq.exchange}")
	String exchange;

	@Value("${metallica.rabbitmq.routingKey}")
	private String routingkey;

	
	
	public void send(T trades) {
		template.convertAndSend("/topic/trades", trades);
	    
	}
}
