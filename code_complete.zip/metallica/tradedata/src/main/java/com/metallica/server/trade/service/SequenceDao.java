package com.metallica.server.trade.service;

public interface SequenceDao {
	
	long getNextSequenceId(String key);
}
