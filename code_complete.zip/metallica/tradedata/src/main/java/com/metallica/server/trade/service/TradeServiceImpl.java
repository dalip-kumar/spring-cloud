/**
 * 
 */
package com.metallica.server.trade.service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.metallica.common.dto.SearchTrade;
import com.metallica.common.dto.Trade;
import com.metallica.common.dto.TradeForm;
import com.metallica.common.enums.Side;
import com.metallica.common.enums.TradeStatus;
import com.metallica.common.exception.RecordNotFoundException;

/**
 * @author dkum74
 *
 */
@Service
public class TradeServiceImpl implements TradeService{

	private static final String TRADE_SEQ_KEY = "tradeId";
	
	private static final String DATE_FORMAT = "dd-MM-yyyy";
	
	private static final String UTC_TIME_ZONE = "UTC";
	
	private static final String ACTIVE_FLG = "Y";
	
	private static final String INACTIVE_FLG = "N";
	
	@Autowired
	private MongoTemplate mangoTemplate;
	
	@Autowired
	private SequenceDao sequenceDao;
	
	
	@Override
	public Collection<Trade> getTrades() {
		Collection<Trade> trades = new ArrayList<>();
		Query query = new Query();
		query.addCriteria(Criteria.where("activeFlag").is(ACTIVE_FLG));
		  
		trades = mangoTemplate.find(query, Trade.class);
		return trades;
	}
	
	public Collection<Trade> getTrades(SearchTrade search) {
		Collection<Trade> trades = new ArrayList<>();
		DateFormat dateFormDate = new SimpleDateFormat(DATE_FORMAT);
		dateFormDate.setTimeZone(TimeZone.getTimeZone(UTC_TIME_ZONE) );
		
		  Query query = new Query();
		  query.addCriteria(Criteria.where("activeFlag").is(ACTIVE_FLG));
		  try {
				  if(StringUtils.isNotBlank(search.getFromDate()) && StringUtils.isNotBlank(search.getToDate())){
						
						query.addCriteria(Criteria.where("tradeDate").gte(dateFormDate.parse(search.getFromDate())).lt(dateFormDate.parse(search.getToDate())));
				  }
		  } catch (ParseException e) {
				e.printStackTrace();
		  }
		  if(StringUtils.isNotBlank(search.getTradeId())){
			  query.addCriteria(Criteria.where("tradeId").is(search.getTradeId()));
		  }
		  if(StringUtils.isNotBlank(search.getSide())){
			  query.addCriteria(Criteria.where("side").is(search.getSide()));
		  }
		  if(StringUtils.isNotBlank(search.getCommodity())){
			  query.addCriteria(Criteria.where("commodity").is(search.getCommodity()));
		  }
		  if(StringUtils.isNotBlank(search.getCounterParty())){
			  query.addCriteria(Criteria.where("counterParty").is(search.getCounterParty()));
		  }
		  if(StringUtils.isNotBlank(search.getLocation())){
			  query.addCriteria(Criteria.where("location").is(search.getLocation()));
		  }
		  trades = mangoTemplate.find(query, Trade.class);

		  
		  return trades;
	}

	public Trade createTrade(TradeForm tradeForm){
		Trade trade = new Trade();
		trade.setTradeId(sequenceDao.getNextSequenceId(TRADE_SEQ_KEY));
		trade.setPrice(new BigDecimal(tradeForm.getPrice()));
		trade.setQuantity(Integer.parseInt(tradeForm.getQuantity()));
		trade.setCommodity(tradeForm.getCommodity());
		trade.setCounterParty(tradeForm.getCounterParty());
		trade.setLocation(tradeForm.getLocation());
		Side side = Side.valueOf(tradeForm.getSide());
		trade.setSide(side);
		trade.setStatus(TradeStatus.OPEN);
		trade.setActiveFlag(ACTIVE_FLG);
		try {
			DateFormat dateFormDate = new SimpleDateFormat(DATE_FORMAT);
			dateFormDate.setTimeZone(TimeZone.getTimeZone(UTC_TIME_ZONE) );
			trade.setTradeDate(dateFormDate.parse(tradeForm.getTradeDate()));
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		mangoTemplate.insert(trade);
		return trade;
	}

	@Override
	public Trade deleteTrade(long tradeId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("tradeId").is(tradeId));
		Trade trade = mangoTemplate.findOne(query, Trade.class);
		if(trade != null){
			trade.setActiveFlag(INACTIVE_FLG);
			mangoTemplate.save(trade);
			return trade;
		}else{
			throw new RecordNotFoundException("Record not found");
		}
		
	}

	@Override
	public Trade updateTrade(TradeForm tradeForm, long tradeId) {
		
		Query query = new Query();
		query.addCriteria(Criteria.where("tradeId").is(tradeId));
		Trade trade = mangoTemplate.findOne(query, Trade.class);
		if(trade != null){
			DateFormat dateFormDate = new SimpleDateFormat(DATE_FORMAT);
			dateFormDate.setTimeZone(TimeZone.getTimeZone(UTC_TIME_ZONE) );
			
			
			trade.setPrice(new BigDecimal(tradeForm.getPrice()));
			trade.setQuantity(Integer.parseInt(tradeForm.getQuantity()));
			trade.setCommodity(tradeForm.getCommodity());
			trade.setCounterParty(tradeForm.getCounterParty());
			trade.setLocation(tradeForm.getLocation());
			Side side = Side.valueOf(tradeForm.getSide());
			trade.setSide(side);
			try {
				trade.setTradeDate(dateFormDate.parse(tradeForm.getTradeDate()));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			
			mangoTemplate.save(trade);
			return trade;
		}else{
			throw new RecordNotFoundException("Record not found");
		}
	}
}
