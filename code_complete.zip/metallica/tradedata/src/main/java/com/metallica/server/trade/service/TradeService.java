package com.metallica.server.trade.service;

import java.util.Collection;

import com.metallica.common.dto.SearchTrade;
import com.metallica.common.dto.Trade;
import com.metallica.common.dto.TradeForm;

public interface TradeService {

	public Collection<Trade> getTrades();
	public Collection<Trade> getTrades(SearchTrade searchCrit);
	
	public Trade createTrade(TradeForm tradeData);
	
	public Trade deleteTrade(long tradeId);
	
	public Trade updateTrade(TradeForm tradeData, long tradeId);
}
