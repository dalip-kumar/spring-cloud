/**
 * 
 */
package com.metallica.auth.repo;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.metallica.auth.model.Users;

/**
 * @author dkum74
 *
 */
@Service
public class MongoUserDetailService implements UserDetailsService{

	
	@Autowired
	private MongoTemplate mangoTemplate;

   
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserDetails loadedUser = null;

        try {
        	
        	Query query = new Query();
    		query.addCriteria(Criteria.where("username").is(username));
//    		query.addCriteria(Criteria.where("password").is(username));
    		Users client = mangoTemplate.findOne(query, Users.class);
    		if(client != null){
    			GrantedAuthority authority = new SimpleGrantedAuthority(client.getRoles().get(0));
    			
    			loadedUser = (UserDetails)new User(client.getUsername(), 
    					client.getPassword(), Arrays.asList(authority));
        	}
        } catch (Exception repositoryProblem) {
            throw new InternalAuthenticationServiceException(repositoryProblem.getMessage(), repositoryProblem);
        }

        if (loadedUser == null) {
            throw new InternalAuthenticationServiceException(
                    "UserDetailsService returned null, which is an interface contract violation");
        }
        return loadedUser;
	}
}
