/**
 * 
 */
package com.metallica.auth.repo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.metallica.auth.model.Users;


/**
 * @author dkum74
 *
 */
public interface UserRepo extends MongoRepository<Users, String> {

	public List<Users> findByusername(String name);
}
