/**
 * 
 */
package com.metallica.auth.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.metallica.auth.model.Users;

/**
 * @author dkum74
 *
 */
//@Service
public class MongoDBAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider{

	
	@Autowired
	private MongoTemplate mangoTemplate;

    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
    }

    @Override
    protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
        UserDetails loadedUser = null;

        try {
        	
        	Query query = new Query();
    		query.addCriteria(Criteria.where("username").is(username));
//    		query.addCriteria(Criteria.where("password").is(username));
    		Users client = mangoTemplate.findOne(query, Users.class);
    		if(client != null){
    			loadedUser = new User(client.getUsername(), client.getPassword(), null);
        	}
        } catch (Exception repositoryProblem) {
            throw new InternalAuthenticationServiceException(repositoryProblem.getMessage(), repositoryProblem);
        }

        if (loadedUser == null) {
            throw new InternalAuthenticationServiceException(
                    "UserDetailsService returned null, which is an interface contract violation");
        }
        return loadedUser;
    }
}
