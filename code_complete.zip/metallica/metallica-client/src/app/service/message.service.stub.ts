import { Observable } from 'rxjs/Observable';
import {Subject} from "rxjs/Subject";


const mockMarketDataResponse = [
  {"name":"IBM","sym":"IBM","price":788.23,"direction":"UP"},
  {"name":"JP Morgan","sym":"JPM","price":1085.23,"direction":"DOWN"}
];

const mockTradeDataResponse = [
  {"id":"5a7053d210e4a220d097e194","tradeId":33,"side":"BUY","quantity":222,"price":23,"tradeDate":1514937600000,"status":"OPEN","commodity":"Sit","counterParty":"IBM Inc.","location":"India","activeFlag":"Y"},
  {"id":"5a7ec4dd61ed3d1c20050b04","tradeId":34,"side":"BUY","quantity":23,"price":898,"tradeDate":1517443200000,"status":"OPEN","commodity":"Sit","counterParty":"Apple Inc.","location":"India","activeFlag":"Y"}
];

export class MessageServiceStub {

 
  private marketDataSource = new Subject<string>();
  marketData$ = this.marketDataSource.asObservable();


  private tradeSource = new Subject<string>();
  messageReceived$ = this.tradeSource.asObservable();

  onTradeData(message) {
    let json = JSON.parse(message.body);
    this.tradeSource.next(json);
  }
  
  onMarketData(mockMarketDataResponse){
    let json = JSON.parse(mockMarketDataResponse.body);
    this.marketDataSource.next(json);
  }
}


