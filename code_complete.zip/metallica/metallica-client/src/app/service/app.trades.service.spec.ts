import {
    fakeAsync,
    inject,
    TestBed,
    tick
  } from '@angular/core/testing';
  import {
    HttpModule,
    XHRBackend,
    ResponseOptions,
    Response,
    RequestMethod
  } from '@angular/http';
  import {
    MockBackend,
    MockConnection
  } from '@angular/http/testing';
import { TradeService } from 'app/service/app.trades.service';
  
  
  const mockCommodityResponse = [
                {"id":"5a3a43947f6b74a4113cd90e","name":"Sit","description":"SIT Commodity"},
                {"id":"5a3a43a97f6b74a4113cd90f","name":"Amet","description":"Amet Commodity"},
                {"id":"5a61bdf32ceab4de723e4b2c","name":"Sit","description":"SIT Commodity"}
            ];

  const mockLocationResponse = [
                {"id":"5a3a43347f6b74a4113cd90c","code":"US","name":"United States of America"},
                {"id":"5a3a43467f6b74a4113cd90d","code":"IN","name":"India"}
            ];

  const mockCounterPartyResponse = [
                {"id":"5a3a148cfd8eb7003d39a421","sym":"AAPL","name":"Apple Inc.","description":"Apple Corporation party"},
                {"id":"5a3a199bfd8eb7003d39a422","sym":"IBM","name":"IBM Inc.","description":"IBM Corporation party"}
            ];


  const mockTradeDataResponse = [
                {"id":"5a7053d210e4a220d097e194","tradeId":33,"side":"BUY","quantity":222,"price":23,"tradeDate":1514937600000,"status":"OPEN","commodity":"Sit","counterParty":"IBM Inc.","location":"India","activeFlag":"Y"},
                {"id":"5a7ec4dd61ed3d1c20050b04","tradeId":34,"side":"BUY","quantity":23,"price":898,"tradeDate":1517443200000,"status":"OPEN","commodity":"Sit","counterParty":"Apple Inc.","location":"India","activeFlag":"Y"},
                {"id":"5af47ff5d780f22538837fd3","tradeId":35,"side":"BUY","quantity":444,"price":444,"tradeDate":1526601600000,"status":"OPEN","commodity":"Amet","counterParty":"Apple Inc.","location":"India","activeFlag":"Y"},
                {"id":"5af5cb3a19c18624fcf51eb5","tradeId":36,"side":"SELL","quantity":111,"price":111,"tradeDate":1526601600000,"status":"OPEN","commodity":"Sit","counterParty":"Apple Inc.","location":"India","activeFlag":"Y"}
            ]



  describe('Trade Data service', () => {
    
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [HttpModule],
        providers: [
          {
            provide: XHRBackend,
            useClass: MockBackend
          },
          TradeService
        ]
      });
    });
    
    it('should get commodities using getCommodity()', fakeAsync(
      inject([
        XHRBackend,
        TradeService
      ], (mockBackend: MockBackend, tradeService: TradeService) => {
        
        const expectedUrl = '/reference/commodity';
        
        mockBackend.connections.subscribe(
          (connection: MockConnection) => {
            expect(connection.request.method).toBe(RequestMethod.Get);
            expect(connection.request.url).toBe(expectedUrl);
            
            connection.mockRespond(new Response(
              new ResponseOptions({ body: mockCommodityResponse })
            ));
          });
  
        tradeService.getCommodities()
          .subscribe(res => {
            expect(res).toEqual(mockCommodityResponse);
          });
      })
    ));
    
   
    it('should get locations using getLocation()', fakeAsync(
        inject([
          XHRBackend,
          TradeService
        ], (mockBackend: MockBackend, tradeService: TradeService) => {
          
          const expectedUrl = '/reference/location';
          
          mockBackend.connections.subscribe(
            (connection: MockConnection) => {
              expect(connection.request.method).toBe(RequestMethod.Get);
              expect(connection.request.url).toBe(expectedUrl);
              
              connection.mockRespond(new Response(
                new ResponseOptions({ body: mockLocationResponse })
              ));
            });
    
          tradeService.getLocations()
            .subscribe(res => {
              expect(res).toEqual(mockLocationResponse);
            });
        })
      ));
    
      it('should get CounterParties using getCounterParties()', fakeAsync(
        inject([
          XHRBackend,
          TradeService
        ], (mockBackend: MockBackend, tradeService: TradeService) => {
          
          const expectedUrl = '/reference/counterparty';
          
          mockBackend.connections.subscribe(
            (connection: MockConnection) => {
              expect(connection.request.method).toBe(RequestMethod.Get);
              expect(connection.request.url).toBe(expectedUrl);
              
              connection.mockRespond(new Response(
                new ResponseOptions({ body: mockCounterPartyResponse })
              ));
            });
    
          tradeService.getCounterParties()
            .subscribe(res => {
              expect(res).toEqual(mockCounterPartyResponse);
            });
        })
      ));

      it('should get trades using getTrades()', fakeAsync(
        inject([
          XHRBackend,
          TradeService
        ], (mockBackend: MockBackend, tradeService: TradeService) => {
          
          const expectedUrl = '/tradedata/trades';
          
          mockBackend.connections.subscribe(
            (connection: MockConnection) => {
              expect(connection.request.method).toBe(RequestMethod.Get);
              expect(connection.request.url).toBe(expectedUrl);
              
              connection.mockRespond(new Response(
                new ResponseOptions({ body: mockTradeDataResponse })
              ));
            });
    
          tradeService.getTrades(null)
            .subscribe(res => {
              expect(res).toEqual(mockTradeDataResponse);
              expect(res.length).toBe(4);
            });
        })
      ));

      it('should create new trade using createTrade()', fakeAsync(
        inject([
          XHRBackend,
          TradeService
        ], (mockBackend: MockBackend, tradeService: TradeService) => {
          
          const expectedUrl = '/tradedata/trades';
          
          mockBackend.connections.subscribe(
            (connection: MockConnection) => {

              expect(connection.request.url).toBe(expectedUrl);
              expect(connection.request.method).toBe(RequestMethod.Post);
       
              connection.mockRespond(new Response(
                  new ResponseOptions({status: 201})));
              });
              
              let tradeDetail = {"tradeDate":"17-05-2018","commodity":"Amet","side":"BUY","counterParty":"IBM Inc.","location":"India","price":"111","quantity":"222"};
          tradeService.createTrade(tradeDetail)
            .subscribe(res => {
              expect(res).toBeDefined();
              expect(res.status).toBe(201);
            });
        })
      ));

      it('should update trade using updateTrade()', fakeAsync(
        inject([
          XHRBackend,
          TradeService
        ], (mockBackend: MockBackend, tradeService: TradeService) => {
          
          const expectedUrl = '/tradedata/trades/31';
          
          mockBackend.connections.subscribe(
            (connection: MockConnection) => {

              expect(connection.request.url).toBe(expectedUrl);
              expect(connection.request.method).toBe(RequestMethod.Put);
       
              connection.mockRespond(new Response(
                  new ResponseOptions({status: 201})));
              });
              
              let tradeDetail = {"tradeDate":"03-01-2018","commodity":"Sit","side":"SELL","counterParty":"IBM Inc.","location":"India","price":23,"quantity":222};
          tradeService.updateTrade(tradeDetail, 31)
            .subscribe(res => {
                //console.log
              expect(res).toBeDefined();
              expect(res.status).toBe(201);
            });
        })
      ));
  });