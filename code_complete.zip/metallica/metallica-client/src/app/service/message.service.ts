import {Injectable} from '@angular/core';
import {Client, Frame} from "stompjs";

import * as stompjs from 'stompjs';
import * as SockJS from "sockjs-client";
import {Subject} from "rxjs/Subject";

@Injectable()
export class MessageService {

  private tradeSource = new Subject<string>();
  messageReceived$ = this.tradeSource.asObservable();

  private marketDataSource = new Subject<string>();
  marketData$ = this.marketDataSource.asObservable();

  stompClient: Client;

  constructor() {

    const socket = new SockJS('http://localhost:7001/metallic-websocket') as WebSocket;
    
    this.stompClient = stompjs.over(socket);
    
    this.stompClient.connect('','', (frame: Frame) => {
      this.stompClient.subscribe('/topic/trades', (message) => {
        this.onTradeData(message);
      });

      this.stompClient.subscribe('/topic/marketdata', (marketData) => {
        this.onMarketData(marketData);
      });

    });
  }


  onTradeData(message) {
    let json = JSON.parse(message.body);
    this.tradeSource.next(json);
  }

  onMarketData(message) {
    let json = JSON.parse(message.body);
    this.marketDataSource.next(json);
  }

}
