import { Observable } from 'rxjs/Observable';
import {Subject} from "rxjs/Subject";
import { TradeService } from 'app/service/app.trades.service';



const mockTradeDataResponse = [
  {"id":"5a7053d210e4a220d097e194","tradeId":33,"side":"BUY","quantity":222,"price":23,"tradeDate":1514937600000,"status":"OPEN","commodity":"Sit","counterParty":"IBM Inc.","location":"India","activeFlag":"Y"},
  {"id":"5a7ec4dd61ed3d1c20050b04","tradeId":34,"side":"BUY","quantity":23,"price":898,"tradeDate":1517443200000,"status":"OPEN","commodity":"Sit","counterParty":"Apple Inc.","location":"India","activeFlag":"Y"}
];

export class TradeServiceStub extends TradeService{

 
    getTrades(tradeDetails){
        return Observable.of(mockTradeDataResponse);
        
    }
}


