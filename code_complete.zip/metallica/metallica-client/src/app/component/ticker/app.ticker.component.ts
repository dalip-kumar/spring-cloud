import { Component, OnInit, OnDestroy} from '@angular/core';
import {MessageService} from "app/service/message.service";
import {Subscription} from "rxjs/Subscription";
@Component({
  selector: 'app-metallica-ticker',
  templateUrl: './app.ticker.component.html',
  styleUrls: ['./app.ticker.component.css'],
  providers: []
})
export class TickerComponent implements OnInit, OnDestroy{
  
  messages: Array<string> = [];

  messageSub: Subscription;

  marketData;
  constructor(private messageService: MessageService){
    
  }
  
 
  ngOnInit(){
    this.messageSub = this.messageService.marketData$.subscribe( data => {
      this.marketData = data;
     
    });
  }
  
   ngOnDestroy() {
    if ( this.messageSub ) {
     this.messageSub.unsubscribe();
   }
   
   
 }

  

}
