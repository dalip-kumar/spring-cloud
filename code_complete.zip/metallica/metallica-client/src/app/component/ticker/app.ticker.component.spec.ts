import {
    inject,
    tick,
    TestBed,
    getTestBed,
    async,
    fakeAsync,
    ComponentFixture
  } from '@angular/core/testing';
  import { Observable } from 'rxjs/Rx';
  
  import { MessageServiceStub } from 'app/service/message.service.stub';
import { TickerComponent } from 'app/component/ticker/app.ticker.component';
import { MessageService } from 'app/service/message.service';
   
  let comp: TickerComponent;
  let fixture: ComponentFixture<TickerComponent>;
  let dataStub: MessageService;
  let element: any;
  
  const mockMarketDataResponse = [
    {"name":"IBM","sym":"IBM","price":788.23,"direction":"UP"},
    {"name":"JP Morgan","sym":"JPM","price":1085.23,"direction":"DOWN"}
  ];

  describe('TickerComponent', () => {
  
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [ TickerComponent ]
      }).overrideComponent(TickerComponent, {
        set: {
          providers: [
            { provide: MessageService, useClass: MessageServiceStub },
          ]
        }
      }).compileComponents()
      .then(() => {
        fixture = TestBed.createComponent(TickerComponent);
        comp = fixture.componentInstance;
        dataStub = fixture.debugElement.injector.get(MessageService);
        element = fixture.debugElement.nativeElement;
      });
    }));
    it('should resolve test data', fakeAsync(() => {
     
      comp.marketData = mockMarketDataResponse;
      comp.ngOnInit();
      fixture.detectChanges();

      expect(comp.marketData).toEqual(mockMarketDataResponse);
      expect(element.querySelectorAll('.direction-down').length).toEqual(1);
      expect(element.querySelectorAll('.direction-up').length).toEqual(1);
      expect(element.querySelectorAll('.ticker__item').length).toEqual(2);

    }));
  });