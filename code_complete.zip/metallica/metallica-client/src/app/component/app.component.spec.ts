/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { TickerComponent } from './ticker/app.ticker.component';
import { MessageService } from '../service/message.service';
import { Component } from '@angular/core';
import { TradesTableComponent } from './trades/app.tradestable.component';
import { TradeDetailComponent } from './trade-detail/app.tradedetail.component';
import { TradeService } from '../service/app.trades.service';
import { HttpModule } from '@angular/http';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TradeServiceStub } from '../service/app.trades.service.stub';
import { ErrorHandlerComponent } from './error/app.error.component';

let element: any;

describe('AppComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule, ModalModule.forRoot()],
      declarations: [
        AppComponent,
        TickerComponent,
        MockSearchComponent,
        TradesTableComponent,
        MockTradeDetailComponent,
        ErrorHandlerComponent
                        
      ],
      providers: [
      
        MessageService,
        { provide: TradeService, useClass: TradeServiceStub },
       
      ]
    });
    TestBed.compileComponents();
  });

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

  it('should have as header', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    element = fixture.debugElement.nativeElement;
    expect(element.querySelectorAll('.navbar-header').length).toEqual(1);
    

  }));

});


@Component({
  selector: 'app-metallica-search',
  template: ''
})
export class MockSearchComponent {
}


@Component({
  selector: 'app-metallica-tradedetail',
  template: ''
})
export class MockTradeDetailComponent {
}