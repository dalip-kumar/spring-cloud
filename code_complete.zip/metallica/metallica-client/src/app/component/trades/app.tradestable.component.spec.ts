import {
    inject,
    tick,
    TestBed,
    getTestBed,
    async,
    fakeAsync,
    ComponentFixture
  } from '@angular/core/testing';
  import { Observable } from 'rxjs/Rx';
  

import { TradesTableComponent } from 'app/component/trades/app.tradestable.component';
import { MessageService } from 'app/service/message.service';
import { MessageServiceStub } from 'app/service/message.service.stub';
import { TradeService } from 'app/service/app.trades.service';
import { HttpModule } from '@angular/http';
import { BsModalService } from 'ngx-bootstrap/modal/bs-modal.service';
import { ModalDirective } from 'ngx-bootstrap/modal/modal.directive';
import { ModalModule } from 'ngx-bootstrap/modal/modal.module';
import { TradeServiceStub } from 'app/service/app.trades.service.stub';
   
  let comp: TradesTableComponent;
  let fixture: ComponentFixture<TradesTableComponent>;
  let dataStub: MessageService;
  let tradeService: TradeService;
  let element: any;
  
  const mockTradeDataResponse = [
        {"id":"5a7053d210e4a220d097e194","tradeId":33,"side":"BUY","quantity":222,"price":23,"tradeDate":1514937600000,"status":"OPEN","commodity":"Sit","counterParty":"IBM Inc.","location":"India","activeFlag":"Y"},
        {"id":"5a7ec4dd61ed3d1c20050b04","tradeId":34,"side":"BUY","quantity":23,"price":898,"tradeDate":1517443200000,"status":"OPEN","commodity":"Sit","counterParty":"Apple Inc.","location":"India","activeFlag":"Y"}
    ];


  describe('TradeTableComponent', () => {
  
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [ TradesTableComponent ],
        imports: [HttpModule, ModalModule.forRoot()]
      }).overrideComponent(TradesTableComponent, {
        set: {
            
          providers: [
            { provide: MessageService, useClass: MessageServiceStub },
            { provide: TradeService, useClass: TradeServiceStub },
            
            ,
            BsModalService
           
          ]
        }
      }).compileComponents()
      .then(() => {
        fixture = TestBed.createComponent(TradesTableComponent);
        comp = fixture.componentInstance;
        dataStub = fixture.debugElement.injector.get(MessageService);
        tradeService = fixture.debugElement.injector.get(TradeService);
        element = fixture.debugElement.nativeElement;
      });
    }));
    it('should resolve test data', fakeAsync(() => {
     
        const spy = spyOn(tradeService, 'getTrades').and.returnValue(
            Observable.of(mockTradeDataResponse)
          );

     // comp.allTrades = mockTradeDataResponse;
      comp.ngOnInit();
      fixture.detectChanges();
          
      expect(comp.allTrades).toEqual(mockTradeDataResponse);
      expect(element.querySelectorAll('.counter-bar').length).toEqual(1);
      expect(element.querySelectorAll('tr.hoveraction').length).toEqual(2);
      expect(element.querySelectorAll('tbody tr').length).toEqual(2);
      

    }));
  });