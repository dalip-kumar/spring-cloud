import { Component, OnInit, OnDestroy,TemplateRef,ViewChild   } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import {TradeService} from 'app/service/app.trades.service';

import {Subscription} from "rxjs/Subscription";



import {IMyDpOptions} from '../../../../node_modules/angular4-datepicker/src/my-date-picker/interfaces';

import { BsModalService,ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';


@Component({
  selector: 'app-metallica-tradedetail',
  templateUrl: './app.tradedetail.component.html',
  styleUrls: ['./app.tradedetail.component.css'],
  providers: []
})
export class TradeDetailComponent  implements OnInit, OnDestroy{
  form;
  trades;
  commodities;
  counterParties;
  locations;
  sides;

  modalRef: BsModalRef;
  tradeDetail;

  isViewMode;

  @ViewChild('tradeDataModal') 
  tradeRecordModal: ModalDirective;

  tradeRecordSub: Subscription;




  public myDatePickerOptions: IMyDpOptions = {
    // other options...
      todayBtnTxt: 'Today',
      dateFormat: 'dd-mm-yyyy',
      firstDayOfWeek: 'mo',
      sunHighlight: true,
      satHighlight:true,
      inline: false,
      height: '34px',
      width: '100%',
  };




  constructor(private tradeDetailForm: FormBuilder, private tradeService: TradeService,
                private modalService: BsModalService){
               
  }

  ngOnInit(){
    this.tradeService.getCommodities().subscribe(data => this.commodities = data);
    this.tradeService.getCounterParties().subscribe(data => this.counterParties = data);
    this.tradeService.getLocations().subscribe(data => this.locations = data);
    this.sides = this.tradeService.getSides();
    this.isViewMode = false;
    this.form = this.tradeDetailForm.group({
      tradeDate : [null, Validators.required],
      commodity: [null, Validators.required],
      side: [null, Validators.required],
      counterParty: [null, Validators.required],
      location: [null, Validators.required],
      price: [null, Validators.required],
      quantity: [null, Validators.required]
    });
  
    this.tradeRecordSub = this.tradeService.getTradeDetail().subscribe(data => {
      
      this.tradeDetail = data;
      this.isViewMode = true;
      this.tradeRecordModal.show();
    });
   
   
  }
  
  addTradeModal() {
    this.tradeDetail = undefined;
    this.form.reset();
    this.tradeRecordModal.show();
  }

  saveTrade(tradeForm, tradeDetail){
    tradeForm.tradeDate = this.form.controls['tradeDate'].value.formatted;
    if(tradeDetail && tradeDetail.tradeId > 0){
      this.tradeService.updateTrade(tradeForm, tradeDetail.tradeId).subscribe(data => {
        this.tradeRecordModal.hide();
      });
    }else{
      this.tradeService.createTrade(tradeForm).subscribe(data => {
        this.tradeRecordModal.hide();
      });
    }
    
  }

  cancel(){
    this.tradeDetail = undefined;
    this.form.reset();
    this.tradeRecordModal.hide();
    this.isViewMode = false;
  }

  editTrade(){
    
    this.isViewMode = false;

    this.form.controls['tradeDate'].setValue(this.tradeDetail.tradeDate);


    let date = new Date(this.tradeDetail.tradeDate);
        this.form.patchValue({tradeDate: {
        date: {
            year: date.getFullYear(),
            month: date.getMonth() + 1,
            day: date.getDate()}
        }});

    this.form.controls['commodity'].setValue(this.tradeDetail.commodity);
    this.form.controls['side'].setValue(this.tradeDetail.side);
    this.form.controls['counterParty'].setValue(this.tradeDetail.counterParty);
    this.form.controls['location'].setValue(this.tradeDetail.location);
    this.form.controls['price'].setValue(this.tradeDetail.price);
    this.form.controls['quantity'].setValue(this.tradeDetail.quantity);
   
   

  }
  ngOnDestroy() {
    
    if(this.tradeRecordSub){
      this.tradeRecordSub.unsubscribe();
    }

   
  }

  
 
}


