import { Component, OnInit, group,TemplateRef } from '@angular/core';
import {FormBuilder, FormArray, Validators} from '@angular/forms';
import {TradeService} from 'app/service/app.trades.service';
import {IMyDpOptions} from '../../../../node_modules/angular4-datepicker/src/my-date-picker/interfaces';



var today = new Date();

@Component({
  selector: 'app-metallica-search',
  templateUrl: './app.search.component.html',
  styleUrls: ['./app.search.component.css'],
  providers: []
})
export class SearchComponent implements OnInit{
  title = 'app Search!';
  trades;
  commodities;
  counterParties;
  locations;
  //sides;
  form;
  sides;


  constructor(private searchFormBuilder: FormBuilder, private tradeService: TradeService){
    
  }
  
  
  public myDatePickerOptions: IMyDpOptions = {
    // other options...
      todayBtnTxt: 'Today',
      dateFormat: 'dd-mm-yyyy',
      firstDayOfWeek: 'mo',
      sunHighlight: true,
      satHighlight:true,
      inline: false,
      height: '34px',
      width: '150px',
  };

  ngOnInit(){
    this.tradeService.getCommodities().subscribe(data => this.commodities = data);
    this.tradeService.getCounterParties().subscribe(data => this.counterParties = data);
    this.tradeService.getLocations().subscribe(data => this.locations = data);
    this.sides = this.tradeService.getSides();
    
    this.form = this.searchFormBuilder.group({
      fromDate : [null, Validators.required],
      toDate: [null, Validators.required],
      commodity: this.searchFormBuilder.control(''),
      side: this.searchFormBuilder.control(''),
      counterParty: this.searchFormBuilder.control(''),
      location: this.searchFormBuilder.control('')
    });
  }
  
  onSearch(searchForm){
    debugger;
    if(this.form.controls['fromDate'].value != undefined){
      searchForm.fromDate = this.form.controls['fromDate'].value.date;
    }
    
    if(this.form.controls['toDate'].value != undefined){
      searchForm.toDate = this.form.controls['toDate'].value.date;
    }

    
    this.tradeService.setFilterTrades(searchForm);
   
    // this.tradeService.getTrades(searchForm).subscribe(data => this.trades = data);
  }

  onClearSearch(){
    this.form.reset();
    this.tradeService.setFilterTrades(null);
  }

}
