import {
    inject,
    tick,
    TestBed,
    getTestBed,
    async,
    fakeAsync,
    ComponentFixture
  } from '@angular/core/testing';
  import { Observable } from 'rxjs/Rx';
  


import { TradeService } from 'app/service/app.trades.service';
import { HttpModule } from '@angular/http';
import { TradeServiceStub } from 'app/service/app.trades.service.stub';
import { SearchComponent } from './app.search.component';
import { MyDatePicker } from 'angular4-datepicker/src/my-date-picker/my-date-picker.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MyDatePickerModule } from 'angular4-datepicker/src/my-date-picker/my-date-picker.module';
   
  let comp: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;
  let tradeService: TradeService;
  let element: any;
  


const mockCommodityResponse = [
    {"id":"5a3a43947f6b74a4113cd90e","name":"Sit","description":"SIT Commodity"},
    {"id":"5a3a43a97f6b74a4113cd90f","name":"Amet","description":"Amet Commodity"},
    {"id":"5a61bdf32ceab4de723e4b2c","name":"Sit","description":"SIT Commodity"}
];

const mockLocationResponse = [
    {"id":"5a3a43347f6b74a4113cd90c","code":"US","name":"United States of America"},
    {"id":"5a3a43467f6b74a4113cd90d","code":"IN","name":"India"}
];

const mockCounterPartyResponse = [
    {"id":"5a3a148cfd8eb7003d39a421","sym":"AAPL","name":"Apple Inc.","description":"Apple Corporation party"},
    {"id":"5a3a199bfd8eb7003d39a422","sym":"IBM","name":"IBM Inc.","description":"IBM Corporation party"}
];



  describe('SearchComponent', () => {
  
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [ SearchComponent ],
        imports: [HttpModule, ReactiveFormsModule, FormsModule, MyDatePickerModule]
      }).overrideComponent(SearchComponent, {
        set: {
            
          providers: [
            
            { provide: TradeService, useClass: TradeServiceStub }
            
           
           
          ]
        }
      }).compileComponents()
      .then(() => {
        fixture = TestBed.createComponent(SearchComponent);
        comp = fixture.componentInstance;
        tradeService = fixture.debugElement.injector.get(TradeService);
        element = fixture.debugElement.nativeElement;
      });
    }));
    it('should resolve test data', fakeAsync(() => {
     
        const spyCommodities = spyOn(tradeService, 'getCommodities').and.returnValue(
            Observable.of(mockCommodityResponse)
          );

          const spyCounterParty = spyOn(tradeService, 'getCounterParties').and.returnValue(
            Observable.of(mockCounterPartyResponse)
          );

          const spyLocation = spyOn(tradeService, 'getLocations').and.returnValue(
            Observable.of(mockLocationResponse)
          );

     
      comp.ngOnInit();
      fixture.detectChanges();
          
      expect(comp.commodities).toEqual(mockCommodityResponse);
      expect(comp.counterParties).toEqual(mockCounterPartyResponse);
      expect(comp.locations).toEqual(mockLocationResponse);
      expect(element.querySelectorAll('select[name="commodity"] > option').length).toEqual(4);
      expect(element.querySelectorAll('select[name="location"] > option').length).toEqual(3);
      expect(element.querySelectorAll('select[name="counterParty"] > option').length).toEqual(3);
      expect(element.querySelectorAll('select[name="side"] > option').length).toEqual(3);

    }));
  });